struct Chunk {
  void* memoryAddress;
  int chunkSize;
  bool beingUsed;
};
